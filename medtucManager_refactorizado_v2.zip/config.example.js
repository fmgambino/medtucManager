window.TM_CONFIG = {
  SUPABASE_URL: 'https://TU-PROYECTO.supabase.co',
  SUPABASE_ANON_KEY: 'TU_ANON_PUBLIC_KEY',
  APP_ENV: 'demo' // cambiar a 'production' cuando Supabase esté configurado
};
