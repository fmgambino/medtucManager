-- TICKET MANAGER © 2026 Tucumán - Argentina
-- Supabase PostgreSQL schema. Ejecutar en SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.users (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  email text not null unique,
  role text not null check (role in ('SuperAdmin','Administrador','Tecnico','Usuario')),
  department text,
  status text not null default 'Activo',
  created_at timestamptz not null default now(),
  updated_at timestamptz
);

create table if not exists public.roles (
  id uuid primary key default gen_random_uuid(),
  role text not null,
  module text not null,
  can_view boolean not null default true,
  can_create boolean not null default false,
  can_edit boolean not null default false,
  can_delete boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz
);

create table if not exists public.service_orders (
  id uuid primary key default gen_random_uuid(),
  nro_orden text,
  sat_id text,
  fecha_ingreso date,
  dependencia text,
  solicitante text,
  bien_tipo text,
  bien_marca text,
  bien_modelo text,
  serie text,
  problema text,
  diagnostico text,
  solucion text,
  tecnico text,
  prioridad text default 'Media',
  estado text default 'Pendiente',
  created_at timestamptz not null default now(),
  updated_at timestamptz
);

create table if not exists public.inventory (
  id uuid primary key default gen_random_uuid(),
  codigo text,
  tipo text,
  marca text,
  modelo text,
  serie text,
  dependencia text,
  estado text default 'Activo',
  created_at timestamptz not null default now(),
  updated_at timestamptz
);

create table if not exists public.loans (
  id uuid primary key default gen_random_uuid(),
  inventario_codigo text,
  destinatario text,
  dependencia text,
  fecha_prestamo date,
  fecha_devolucion date,
  responsable text,
  estado text default 'Activo',
  created_at timestamptz not null default now(),
  updated_at timestamptz
);

create table if not exists public.tickets (
  id uuid primary key default gen_random_uuid(),
  ticket_nro text,
  fecha date,
  oficina text,
  solicitante text,
  email text,
  categoria text,
  descripcion text,
  prioridad text default 'Media',
  estado text default 'Abierto',
  created_at timestamptz not null default now(),
  updated_at timestamptz
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  message text not null,
  read boolean not null default false,
  created_at timestamptz not null default now()
);

alter table public.users enable row level security;
alter table public.roles enable row level security;
alter table public.service_orders enable row level security;
alter table public.inventory enable row level security;
alter table public.loans enable row level security;
alter table public.tickets enable row level security;
alter table public.notifications enable row level security;

-- Políticas simples para usuarios autenticados. Endurecer en producción según rol.
do $$ declare t text; begin
  foreach t in array array['users','roles','service_orders','inventory','loans','tickets','notifications'] loop
    execute format('drop policy if exists authenticated_crud on public.%I', t);
    execute format('create policy authenticated_crud on public.%I for all to authenticated using (true) with check (true)', t);
  end loop;
end $$;

insert into public.users(full_name,email,role,department,status)
values ('Ing. Fernando Gambino','fernando.m.gambino@gmail.com','SuperAdmin','Dirección de Informática','Activo')
on conflict (email) do update set role='SuperAdmin', status='Activo';

-- Crear en Supabase Authentication un usuario con:
-- Email: fernando.m.gambino@gmail.com
-- Password: Jamboree0342$$
