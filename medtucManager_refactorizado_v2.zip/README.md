# Ticket Manager PWA

PWA HTML5/CSS3/JS + SweetAlert2 + Supabase para control de tickets, órdenes técnicas, inventario, préstamos, roles y notificaciones.

## Probar local
Abrir `index.html` o publicar en GitHub Pages. En modo demo usar:

- Usuario: `fernando.m.gambino@gmail.com`
- Contraseña: `Jamboree0342$$`

## Producción con Supabase
1. Crear proyecto Supabase.
2. Ejecutar `supabase-schema.sql` en SQL Editor.
3. Crear el usuario en Authentication con el email y contraseña indicados.
4. Copiar `config.example.js` como `config.js`.
5. Completar `SUPABASE_URL`, `SUPABASE_ANON_KEY` y cambiar `APP_ENV` a `production`.
6. Subir todo a GitHub Pages.

## Importación SATMANAGER Access
GitHub Pages no puede leer `.MDB` directamente porque es una app estática sin backend/driver ODBC. Flujo recomendado:

1. Abrir `GX_DATA.MDB` en Microsoft Access.
2. Exportar las tablas de órdenes técnicas a CSV.
3. En Ticket Manager ir a **Órdenes de Servicio > Importar CSV**.
4. Usar columnas compatibles con `templates/service_orders_template.csv`.

Se incluye `tools/SATMANAGER_IMPORT_GUIDE.md` con el mapeo sugerido.

## Exportación
Todos los módulos incluyen Exportar CSV y PDF A4 con membrete, fecha y hora.
