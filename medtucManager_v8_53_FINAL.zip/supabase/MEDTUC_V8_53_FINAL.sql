-- MEDTUC v8.53 FINAL
-- Hotfix compatible con v8.52.
-- Mantiene app_icon_url y refuerza permisos completos para SuperAdmin.

ALTER TABLE public.app_settings
ADD COLUMN IF NOT EXISTS app_icon_url text DEFAULT 'https://www.educaciontuc.gov.ar/wp-content/uploads/2024/10/cropped-icogob-1-180x180.png';

INSERT INTO public.role_module_permissions (role_name,module_key,can_view,can_create,can_edit,can_delete,can_import,can_export)
SELECT 'SuperAdmin', m, true, true, true, true, true, true
FROM unnest(ARRAY['dashboard','users','roles','orders','inventory','loans','tickets','notifications','offices','exceptions','logs','profile','settings']) AS m
ON CONFLICT DO NOTHING;

UPDATE public.role_module_permissions
SET can_view=true, can_create=true, can_edit=true, can_delete=true, can_import=true, can_export=true, updated_at=now()
WHERE role_name='SuperAdmin';
