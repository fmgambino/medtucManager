# MedTuc Ticket Manager PWA

PWA HTML5 + CSS3 + JavaScript + SweetAlert2 + Supabase, lista para GitHub Pages.

## Usuario demo local
- Email: `fernando.m.gambino@gmail.com`
- Pass: `Jamboree0342$$`

## Archivos principales
- `index.html`: Login y aplicación separados correctamente.
- `app.css`: UX/UI mobile first, tema oscuro/claro e iconografía SVG.
- `app.js`: módulos, CRUD, CSV, PDF A4, notificaciones, PWA install.
- `supabase-schema.sql`: tablas sugeridas para Supabase.
- `config.js`: configurar Supabase o dejar `DEMO_MODE: true` para prueba local.

## Módulos
Dashboard, AMB Usuarios, Roles y Permisos, Órdenes de Servicio, Inventario, Gestión de Préstamos, Soporte Ticket, Notificaciones, Mi Perfil y Cerrar Sesión.

## Importación desde SATMANAGER / Access
Exportar cada tabla o consulta de Access a CSV y luego importarla desde el módulo correspondiente. Para Órdenes de Servicio se sugiere mapear: número, fecha, dependencia/oficina, equipo, serie/patrimonio, falla, técnico y estado.

## Soporte Ticket
El módulo replica los campos principales del formulario SoporteTicketV3: solicitante, email, WhatsApp, servicio solicitado, cantidad de equipos, tipo de equipo, marca, modelo, falla/reclamo, responsable, colaborador y estado.
